**一、简答题**

- 1、Mybatis动态sql是做什么的？都有哪些动态sql？简述一下动态sql的执行原理？

  > ①.根据条件更加灵活拼装sql语句；
  >
  > ②.控制动态sql拼接：if、foearch、choose、where、set、trim、when、otherwise
  >
  > ​     常量定义及引用：sql、include
  >
  > ​     多表关联查询：collection、association
  >
  > ③.根据传参条件，解析及判断生成指定sql语句，通过xml中id和namespace确定具体sql语句，Excecutor解析SQL语句生成sql语句、StatementHandler对象中的ParameterHandler对象设置参数、调用Jdbc  
  >
  > 中SimpleStatement执行sql，返回结果集通过StatementHandler封装，返会给调用方。
  >
  > ​    

- 2、Mybatis是否支持延迟加载？如果支持，它的实现原理是什么？

  > ①.支持;
  >
  > ②.通过动态代理的方式实现，通过配置信息，设置相关的延迟加载配置；实现 ProxyFactory接口，创建代理对象EnhancedResultObjectProxyImpl，执行代理对象时，根据代理设置，判断延迟加载的属性，如果是调用set方法不进行延迟加载处理没如果调用get则使用延时加载方式。

  

- 3、Mybatis都有哪些Executor执行器？它们之间的区别是什么？

  > 抽象类：BaseExecutor 是一个抽象类，实现执行器的基本功能。
  >
  > BatchExecutor 批量执行接口
  >
  >  ReuseExecutor 可重用的执行器，重用的对象是Statement，该执行器会缓存同一个sql的Statement，省去Statement的重新创建，优化性能。
  >
  >  SimpleExecutor 普通执行器

- 4、简述下Mybatis的一级、二级缓存（分别从存储结构、范围、失效场景。三个方面来作答）？

  > ①.一级缓存为sqlSession级别的缓存，缓存底层的存储结构为HashMap。不同的sqlSession之间缓存的数据互不影响。一级缓存在执行新增、修改、删除以及在做sqlSession关闭时会清空sqlSession中的缓存数据。
  >
  > ②.二级缓存为mapper中的namespace级别，也就是说，同一个namespace下，不同的sqlSession下，公用一个缓存；二级缓存的存储结构,Mybatis提供统一的接口，不同的实现方式，存储结构不同；
  >
  > 在做增、删、改、操作会清空。

- 5、简述Mybatis的插件运行原理，以及如何编写一个插件？

  > ①.创建mybatis中四大组件Executor、StatementHandler、ParameterHandler、ResultSetHandler对象时，通过nterceptorChain.pluginAll(parameterHandler);加入拦截器链中，调用Interceptor.plugin(target)返回包装后的对象， 可以通过创建目标代理对象，自定义处理逻辑。
  >
  > ②.通过注解和继承 Interceptor接口，注解：@Intercepts拦截器、@Signature {type 指定拦截接口（四大对象），method=""指定拦截方法、args={} 方法参数}
  >
  > 生成目标代理对象，加入拦截器链中，执行代理对象方法，由代理对象先执行增强逻辑。再执行原始方法。